import * as prService from '../services/purchaseRequest.service.js';
import { sendResponse } from '../utils/response.js';

export const createPurchaseRequest = async (req, res, next) => {
  try {
    const isSuperAdmin = req.user.role?.name === 'SUPER_ADMIN';
    const tenantIdToUse = isSuperAdmin ? (req.body.tenantId || req.user.tenantId) : req.user.tenantId;

    const pr = await prService.createPurchaseRequest(req.body, req.user.id, tenantIdToUse);
    sendResponse(res, 201, 'Purchase Request created successfully', pr);
  } catch (error) {
    next(error);
  }
};

export const getPurchaseRequests = async (req, res, next) => {
  try {
    const isSuperAdmin = req.user.role?.name === 'SUPER_ADMIN';
    const tenantIdToFilter = isSuperAdmin && !req.query.tenantId ? null : (req.query.tenantId ? Number(req.query.tenantId) : req.user.tenantId);

    const result = await prService.getPurchaseRequests(tenantIdToFilter, req.query);
    sendResponse(res, 200, 'Purchase Requests fetched successfully', result);
  } catch (error) {
    next(error);
  }
};

export const getPurchaseRequestById = async (req, res, next) => {
  try {
    const isSuperAdmin = req.user.role?.name === 'SUPER_ADMIN';
    const tenantIdToFilter = isSuperAdmin ? null : req.user.tenantId;

    const pr = await prService.getPurchaseRequestById(Number(req.params.id), tenantIdToFilter);
    sendResponse(res, 200, 'Purchase Request fetched successfully', pr);
  } catch (error) {
    next(error);
  }
};

export const updatePurchaseRequest = async (req, res, next) => {
  try {
    const isSuperAdmin = req.user.role?.name === 'SUPER_ADMIN';
    const tenantIdToFilter = isSuperAdmin ? null : req.user.tenantId;

    const updatedPr = await prService.updatePurchaseRequest(Number(req.params.id), req.body, tenantIdToFilter, req.user.id);
    sendResponse(res, 200, 'Purchase Request updated successfully', updatedPr);
  } catch (error) {
    next(error);
  }
};

export const updatePurchaseRequestStatus = async (req, res, next) => {
  try {
    const isSuperAdmin = req.user.role?.name === 'SUPER_ADMIN';
    const tenantIdToFilter = isSuperAdmin ? null : req.user.tenantId;
    const { status } = req.body;

    const updatedPr = await prService.updatePurchaseRequestStatus(Number(req.params.id), status, tenantIdToFilter, req.user.id);
    sendResponse(res, 200, 'Purchase Request status updated', updatedPr);
  } catch (error) {
    next(error);
  }
};

export const deletePurchaseRequest = async (req, res, next) => {
  try {
    const isSuperAdmin = req.user.role?.name === 'SUPER_ADMIN';
    const tenantIdToFilter = isSuperAdmin ? null : req.user.tenantId;

    await prService.deletePurchaseRequest(Number(req.params.id), tenantIdToFilter, req.user.id);
    sendResponse(res, 200, 'Purchase Request deleted successfully');
  } catch (error) {
    next(error);
  }
};
