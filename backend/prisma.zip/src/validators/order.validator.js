import { z } from 'zod';

const orderItemSchema = z.object({
  itemId: z.number().int().positive('Item ID is required').optional(),
  warehouseId: z.number().int().positive('Warehouse ID is required for stock allocation').optional(),
  quantity: z.union([z.number(), z.string()]).optional(),
  unitPrice: z.union([z.number(), z.string()]).optional(),
  name: z.string().optional(),
  qty: z.union([z.number(), z.string()]).optional(),
  price: z.union([z.number(), z.string()]).optional(),
}).passthrough();

export const createOrderSchema = z.object({
  clientId: z.number({
    required_error: "Client selection is required",
    invalid_type_error: "Client ID must be a number",
  }).int().positive('Client ID must be a positive number'),
  vendorId: z.number().int().positive().nullable().optional(),
  companyId: z.number().int().positive().nullable().optional(),
  priority: z.enum(['normal', 'high', 'urgent']).optional().default('normal'),
  items: z.array(z.any()).optional()
}).passthrough();

export const updateOrderStatusSchema = z.object({
  status: z.enum(['submitted', 'review', 'approved', 'rejected', 'cancelled'], { required_error: 'Valid status is required' })
});
